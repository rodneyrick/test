from importlib.metadata import version, PackageNotFoundError
try:
    # Use the exact package name in pyproject.toml
    __version__ = version("mstv-core")
except PackageNotFoundError:
    __version__ = "unknown" # For Python <3.8

def get_version() -> str:
    return __version__
