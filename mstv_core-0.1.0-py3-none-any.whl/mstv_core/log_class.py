# logclass.py
import os
import logging
import threading

def hex_to_ansi(hex_color: str, background=False) -> str:
    """
    Converts a hexadecimal color code to an ANSI escape sequence for terminal coloring.

    Args:
        hex_color (str): The hexadecimal color code (e.g., '#ff00ff' or 'ff00ff').
        background (bool, optional): If True, returns the ANSI code for background color.
            If False (default), returns the ANSI code for foreground color.

    Returns:
        str: The ANSI escape sequence corresponding to the given color.

    Example:
        >>> hex_to_ansi('#ff00ff')
        '\\x1b[38;2;255;0;255m'
        >>> hex_to_ansi('00ff00', background=True)
        '\\x1b[48;2;0;255;0m'
    """
    hex_color = hex_color.lstrip('#')
    r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    base = '48' if background else '38'
    return f"\x1b[{base};2;{r};{g};{b}m"

class ColorFormatter(logging.Formatter):
    """
    A custom logging formatter that adds ANSI color codes to log messages based on their severity level.

    Attributes:
        COLORS (dict): Maps logging levels to their corresponding hex color codes.
        RESET (str): ANSI escape sequence to reset terminal color formatting.

    Methods:
        format(record):
            Formats the specified log record with color based on its level.
            Converts the hex color code to an ANSI escape sequence using `hex_to_ansi`.
            Returns the colored log message as a string.
    """
    COLORS = {
        logging.DEBUG: "#54cfcf",     # Cyan
        logging.INFO: "#ffffff",      # Green
        logging.WARNING: "#ffff00",   # Yellow
        # logging.ERROR: "#ff00ff",     # Red
        logging.ERROR: "#ff6633",     # Light Red
        # logging.ERROR: "#ff6347",     # Tomato
        # logging.CRITICAL: "#ff00ff"   # Magenta
        logging.CRITICAL: "#ee82ee"   # Violet
    }
    RESET = "\033[0m"

    def format(self, record):
        color_hex = self.COLORS.get(record.levelno, "#ffffff")
        color_ansi = hex_to_ansi(color_hex)
        message = super().format(record)
        return f"{color_ansi}{message}{self.RESET}"


class SuppressLoggerFilter(logging.Filter):
    """
    A logging filter that suppresses log records from specified logger names.

    Args:
        suppressed_names (Iterable[str]): A collection of logger names to suppress.

    Methods:
        filter(record):
            Returns True if the log record's logger name is not in the suppressed_names list,
            effectively allowing only records from non-suppressed loggers.
    """
    def __init__(self, suppressed_names):
        super().__init__()
        self.suppressed_names = suppressed_names

    def filter(self, record):
        """
        Determine if a log record should be processed based on its logger name.

        Args:
            record (logging.LogRecord): The log record to be evaluated.

        Returns:
            bool: True if the record's logger name is not in the list of suppressed names, False otherwise.
        """
        return record.name not in self.suppressed_names

class LogClass:
    """
    # Suppress "db" logs
    LogClass().suppress_loggers("db")
    """
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(LogClass, cls).__new__(cls)
                    cls._instance._init_logger()
        return cls._instance

    def _init_logger(self):
        self._loggers = {}
        self._default_level = os.getenv("LOG_LEVEL", logging.INFO)
        self._formatter = ColorFormatter(
            fmt="%(asctime)s %(levelname)s [%(name)s:%(funcName)s:%(lineno)d] - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        self._suppressed = set()

    def suppress_loggers(self, *names: str):
        """Add logger names to the suppression list."""
        self._suppressed.update(names)

    def get_logger(self, module_name: str = "default", level=None):
        if module_name in self._loggers:
            return self._loggers[module_name]

        logger = logging.getLogger(module_name)
        logger.setLevel(level or self._default_level)
        logger.propagate = False  # Prevent log duplication

        if not logger.handlers:
            stream_handler = logging.StreamHandler()
            stream_handler.setFormatter(self._formatter)
            logger.addHandler(stream_handler)

            # Add suppression filter to the handler
            suppression_filter = SuppressLoggerFilter(self._suppressed)
            stream_handler.addFilter(suppression_filter)

        self._loggers[module_name] = logger
        return logger
    
def logger_test(logger) -> None:
    logger.debug("[DEBUG] Debug message")
    logger.info("[INFO] Debug message")
    logger.warning("[WARNING] Debug message")
    logger.critical("[CRITICAL] Debug message")
    logger.error("[ERROR] Debug message")
