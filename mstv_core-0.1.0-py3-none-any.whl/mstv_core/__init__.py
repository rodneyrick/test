from mstv_core import _version
from mstv_core.log_class import LogClass

__version__ = _version.get_version()

__all__ = [
    "__version__",
    "LogClass"
]